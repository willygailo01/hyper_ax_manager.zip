#!/system/bin/sh
# ============================================================
#   HYPER AX MANAGER — Action Button Handler
#   action.sh — Toggles between Performance ↔ Max Performance
# ============================================================

MODDIR="${0%/*}"
CONFIG="$MODDIR/config"
LOG="$MODDIR/logs/action.log"

log() {
    local TIMESTAMP
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "??:??:??")
    echo "[$TIMESTAMP] [ACTION] $1" >> "$LOG" 2>/dev/null
}

mkdir -p "$CONFIG"
mkdir -p "$MODDIR/logs"

# Get current profile
CURRENT=$(cat "$CONFIG/current_profile" 2>/dev/null || echo "performance")

# Toggle logic
if [ "$CURRENT" = "performance" ]; then
    NEW_PROFILE="max"
    echo "🔥 Switching to MAX PERFORMANCE (Extreme)..."
    log "Toggle: performance → max"
else
    NEW_PROFILE="performance"
    echo "⚡ Switching to PERFORMANCE (Boost)..."
    log "Toggle: max → performance"
fi

# Apply new profile
if command -v hyper-ax >/dev/null 2>&1; then
    hyper-ax apply "$NEW_PROFILE"
else
    sh "$MODDIR/system/bin/hyper-ax" apply "$NEW_PROFILE"
fi

RESULT=$?
if [ $RESULT -eq 0 ]; then
    log "Toggle success → $NEW_PROFILE"
    if [ "$NEW_PROFILE" = "max" ]; then
        echo "✅ MAX PERFORMANCE activated!"
        echo "   CPU: Locked to MAX | GPU: MAX Lock | RAM: Extreme"
    else
        echo "✅ PERFORMANCE (Boost) activated!"
        echo "   CPU: schedutil boost | GPU: Performance | RAM: Optimized"
    fi
else
    log "Toggle FAILED"
    echo "❌ Failed to switch profile. Check logs."
fi
