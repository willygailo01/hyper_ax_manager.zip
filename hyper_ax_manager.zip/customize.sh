#!/system/bin/sh
# ============================================================
#   HYPER AX MANAGER - Installer Script
#   customize.sh
# ============================================================

SKIPUNZIP=0

ui_print ""
ui_print "╔══════════════════════════════════════╗"
ui_print "║       HYPER AX MANAGER v1.0.0        ║"
ui_print "║    Ultimate Android Performance       ║"
ui_print "║         Plugin for AxManager          ║"
ui_print "╚══════════════════════════════════════╝"
ui_print ""
ui_print "  [*] Author   : HyperAX Team"
ui_print "  [*] Platform : AxManager Plugin"
ui_print "  [*] Target   : All Android Versions"
ui_print ""

# ── Device Info Detection ──────────────────────────────────
ui_print "──────────────────────────────────────"
ui_print "  [>] Detecting Device Info..."

SOC=$(getprop ro.board.platform 2>/dev/null)
BRAND=$(getprop ro.product.brand 2>/dev/null)
MODEL=$(getprop ro.product.model 2>/dev/null)
ANDROID_VER=$(getprop ro.build.version.release 2>/dev/null)
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
RAM_GB=$(echo "$RAM_KB" | awk '{printf "%.1f", $1/1024/1024}')

ui_print "  [i] Brand   : $BRAND"
ui_print "  [i] Model   : $MODEL"
ui_print "  [i] SoC     : $SOC"
ui_print "  [i] Android : $ANDROID_VER"
ui_print "  [i] RAM     : ${RAM_GB}GB"
ui_print "  [i] Arch    : $ARCH"

# ── Chipset Detection ──────────────────────────────────────
ui_print ""
ui_print "  [>] Detecting Chipset Type..."

CHIPSET_TYPE="unknown"
GPU_TYPE="unknown"

# Snapdragon detection
if echo "$SOC" | grep -qiE "sm[0-9]+|sdm[0-9]+|msm[0-9]+|qcom|kona|lahaina|taro|kalama|pineapple|niobe|crow"; then
    CHIPSET_TYPE="snapdragon"
    GPU_TYPE="adreno"
    ui_print "  [✓] Detected: Qualcomm Snapdragon (Adreno GPU)"
fi

# MediaTek detection
if echo "$SOC" | grep -qiE "mt[0-9]+|helio|dimensity|g[0-9]+|p[0-9]+"; then
    CHIPSET_TYPE="mediatek"
    GPU_TYPE="mali"
    ui_print "  [✓] Detected: MediaTek (Mali GPU)"
fi

if [ "$CHIPSET_TYPE" = "unknown" ]; then
    ui_print "  [!] Chipset auto-detect fallback to generic mode"
    CHIPSET_TYPE="generic"
    GPU_TYPE="generic"
fi

# Save chipset info for runtime use
echo "CHIPSET_TYPE=$CHIPSET_TYPE" > "$MODPATH/chipset.conf"
echo "GPU_TYPE=$GPU_TYPE" >> "$MODPATH/chipset.conf"
echo "SOC=$SOC" >> "$MODPATH/chipset.conf"
echo "RAM_KB=$RAM_KB" >> "$MODPATH/chipset.conf"

# ── Android Version Check ──────────────────────────────────
ui_print ""
ui_print "  [>] Android Version Check..."
if [ "$API" -ge 21 ]; then
    ui_print "  [✓] Android API $API — Supported!"
else
    ui_print "  [✗] Android API $API — Too old! Minimum API 21"
    abort "  Minimum Android 5.0 (API 21) required!"
fi

# ── Set Permissions ────────────────────────────────────────
ui_print ""
ui_print "  [>] Setting Permissions..."
set_perm_recursive "$MODPATH" root root 0755 0644
set_perm "$MODPATH/service.sh"      root root 0755
set_perm "$MODPATH/action.sh"       root root 0755
set_perm "$MODPATH/uninstall.sh"    root root 0755
set_perm "$MODPATH/system/bin/hyper-ax"      root root 0755
set_perm "$MODPATH/system/bin/hyper-profile" root root 0755

ui_print "  [✓] Permissions set"

# ── Create Runtime Directories ─────────────────────────────
ui_print ""
ui_print "  [>] Creating runtime directories..."
mkdir -p "$MODPATH/logs"
mkdir -p "$MODPATH/config"

# Default profile = Performance
echo "performance" > "$MODPATH/config/current_profile"
ui_print "  [✓] Default profile: Performance (Boost)"

# ── Done ───────────────────────────────────────────────────
ui_print ""
ui_print "──────────────────────────────────────"
ui_print "  [✓] Installation Complete!"
ui_print ""
ui_print "  HOW TO USE:"
ui_print "  • Open AxManager → Plugin tab"
ui_print "  • Tap [Action] to switch profiles"
ui_print "  • Tap [WebUI] for full dashboard"
ui_print ""
ui_print "  PROFILES AVAILABLE:"
ui_print "  • [1] Performance (Boost)"
ui_print "  • [2] Max Performance (Extreme)"
ui_print ""
ui_print "╔══════════════════════════════════════╗"
ui_print "║     Enjoy Hyper AX Manager! 🔥       ║"
ui_print "╚══════════════════════════════════════╝"
ui_print ""
