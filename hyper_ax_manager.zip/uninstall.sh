#!/system/bin/sh
# ============================================================
#   HYPER AX MANAGER — Uninstaller / Restore
#   uninstall.sh
# ============================================================

MODDIR="${0%/*}"
LOG="$MODDIR/logs/uninstall.log"

log() {
    echo "[UNINSTALL] $1" >> "$LOG" 2>/dev/null
}

log "Starting Hyper AX Manager uninstall/restore..."

write_restore() {
    local NODE="$1"
    local VAL="$2"
    [ -f "$NODE" ] && [ -w "$NODE" ] && echo "$VAL" > "$NODE" 2>/dev/null && log "RESTORE $NODE = $VAL"
}

# ── Restore CPU to balanced defaults ──────────────────────
CORE_COUNT=$(ls /sys/devices/system/cpu/ | grep -c "^cpu[0-9]" 2>/dev/null || echo 8)
i=0
while [ $i -lt "$CORE_COUNT" ]; do
    write_restore "/sys/devices/system/cpu/cpu${i}/cpufreq/scaling_governor" "schedutil"
    # Restore max freq
    MAX_FREQ=$(cat "/sys/devices/system/cpu/cpu${i}/cpufreq/cpuinfo_max_freq" 2>/dev/null)
    MIN_FREQ=$(cat "/sys/devices/system/cpu/cpu${i}/cpufreq/cpuinfo_min_freq" 2>/dev/null)
    write_restore "/sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq" "$MAX_FREQ"
    write_restore "/sys/devices/system/cpu/cpu${i}/cpufreq/scaling_min_freq" "$MIN_FREQ"
    i=$((i + 1))
done
log "CPU governor restored to schedutil"

# ── Restore GPU ────────────────────────────────────────────
# Adreno
write_restore "/sys/class/kgsl/kgsl-3d0/devfreq/governor" "msm-adreno-tz"
write_restore "/sys/class/kgsl/kgsl-3d0/force_no_nap" "0"
write_restore "/sys/class/kgsl/kgsl-3d0/throttling" "1"

# Mali
for D in /sys/class/devfreq/*mali*; do
    write_restore "${D}/governor" "mali_ondemand"
done
log "GPU restored to default governor"

# ── Restore VM ─────────────────────────────────────────────
write_restore "/proc/sys/vm/swappiness" "100"
write_restore "/proc/sys/vm/dirty_ratio" "20"
write_restore "/proc/sys/vm/dirty_background_ratio" "5"
write_restore "/proc/sys/vm/vfs_cache_pressure" "100"
log "VM/RAM restored to defaults"

# ── Restore Thermal ────────────────────────────────────────
write_restore "/sys/module/msm_thermal/parameters/enabled" "Y"
log "Thermal restored"

# ── Restore I/O ────────────────────────────────────────────
for BLOCK in /sys/block/*/queue; do
    [ -d "$BLOCK" ] || continue
    write_restore "${BLOCK}/read_ahead_kb" "128"
    write_restore "${BLOCK}/nr_requests" "128"
done
log "I/O restored to defaults"

# ── Restore Network ────────────────────────────────────────
write_restore "/proc/sys/net/ipv4/tcp_congestion_control" "cubic"
write_restore "/proc/sys/net/core/rmem_max" "212992"
write_restore "/proc/sys/net/core/wmem_max" "212992"
log "Network TCP restored to defaults"

log "Hyper AX Manager uninstall complete. Device restored to stock settings."
echo "Hyper AX Manager has been removed. All settings restored to default."
