#!/system/bin/sh
# ============================================================
#   HYPER AX MANAGER — Boot Service
#   service.sh — Executed on BOOT_COMPLETED
# ============================================================

MODDIR="${0%/*}"
CONFIG="$MODDIR/config"
LOG="$MODDIR/logs/service.log"

log() {
    local TIMESTAMP
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "BOOT")
    echo "[$TIMESTAMP] $1" >> "$LOG" 2>/dev/null
}

log "============================================"
log "  HYPER AX MANAGER v1.0.0 — Boot Service"
log "============================================"
log "  AxManager Plugin starting..."

# Wait for system to fully boot
sleep 5

# Ensure directories exist
mkdir -p "$CONFIG"
mkdir -p "$MODDIR/logs"

# Read saved profile
PROFILE=$(cat "$CONFIG/current_profile" 2>/dev/null || echo "performance")
log "  Auto-applying profile: $PROFILE"

# Apply the profile using core engine
if command -v hyper-ax >/dev/null 2>&1; then
    hyper-ax apply "$PROFILE"
    log "  Profile applied via hyper-ax"
else
    # Fallback: source the binary directly
    sh "$MODDIR/system/bin/hyper-ax" apply "$PROFILE"
    log "  Profile applied via direct path"
fi

log "  Service boot complete. Profile: $PROFILE"
log "============================================"
