#!/system/bin/sh
# ============================================================
#   HYPER AX MANAGER — Early Boot Script
#   post-fs-data.sh
# ============================================================

MODDIR="${0%/*}"
LOG="$MODDIR/logs/boot.log"

mkdir -p "$MODDIR/logs"
mkdir -p "$MODDIR/config"

log() {
    echo "[BOOT] $1" >> "$LOG" 2>/dev/null
}

log "Hyper AX Manager early boot init..."

# Ensure default profile config exists
if [ ! -f "$MODDIR/config/current_profile" ]; then
    echo "performance" > "$MODDIR/config/current_profile"
    log "Default profile set: performance"
fi

# Pre-enable CPU boost early
for BOOST in \
    /sys/module/cpu_boost/parameters/input_boost_enabled \
    /sys/kernel/msm_performance/parameters/cpu_min_freq; do
    [ -f "$BOOST" ] && [ -w "$BOOST" ] && echo "1" > "$BOOST" 2>/dev/null
done

log "Early boot init complete"
